// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vouch_app/app_theme.dart';
import 'package:vouch_app/auth_gate.dart';
import 'package:vouch_app/providers/reward_provider.dart';
import 'package:vouch_app/providers/visit_provider.dart';
import 'package:vouch_app/providers/review_provider.dart';

void main() {
  runApp(
    // The provider makes our reward data available to the whole app
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => RewardProvider()),
        ChangeNotifierProvider(create: (context) => VisitProvider()),
        ChangeNotifierProvider(create: (context) => ReviewProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vouch',
      theme: AppTheme.theme,
      home: const AuthGate(),
    );
  }
}
