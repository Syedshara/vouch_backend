// lib/auth_gate.dart
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:vouch_app/pages/login_page.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final LocalAuthentication auth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    // Attempt to authenticate as soon as the widget is built
    _authenticate();
  }

  Future<void> _authenticate() async {
    try {
      bool authenticated = await auth.authenticate(
        localizedReason: 'Scan your fingerprint or face to open Vouch',
        options: const AuthenticationOptions(
          stickyAuth: true, // Keep the prompt open until success/failure
          biometricOnly: true, // Only allow fingerprint/face, not PIN
        ),
      );

      if (authenticated && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      } else {
        // Handle case where user cancels or fails authentication
        // For a real app, you might want to allow PIN entry or exit.
        // For this demo, we'll just keep prompting.
        _authenticate();
      }
    } catch (e) {
      print('Error during authentication: $e');
      // If biometrics are not set up, go directly to login for this demo
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Show a loading/waiting screen while the biometric prompt is up
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.fingerprint, color: Theme.of(context).primaryColor, size: 80),
            const SizedBox(height: 20),
            const Text('Waiting for authentication...', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}