// lib/pages/home_page.dart
import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:vouch_app/app_theme.dart';
import 'package:vouch_app/components/top_10_carousel.dart';
import 'package:vouch_app/components/filter_panel.dart';
import 'package:vouch_app/pages/business_detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isMapView = false;
  String _selectedCategory = 'All';
  String _selectedSort = 'distance';

  final List<Map<String, String>> nearbyPlaces = const [
    {'id': 'annapoorna', 'name': 'Annapoorna Gowrishankar', 'category': 'South Indian', 'campaign': 'Visit 3 times, get a free filter coffee!', 'distance': '0.3 km away'},
    {'id': 'brookfields', 'name': 'Brookfields Mall', 'category': 'Shopping', 'campaign': 'Spend ₹2000, get 100 points!', 'distance': '1.2 km away'},
    {'id': 'frenchdoor', 'name': 'The French Door', 'category': 'Cafe & Bakery', 'campaign': 'Every 5th visit gets a free pastry!', 'distance': '2.5 km away'},
    {'id': 'crosscut', 'name': 'Cross-Cut Road', 'category': 'Street Shopping', 'campaign': 'Vouch at 3 shops, get a surprise reward!', 'distance': '3.1 km away'},
  ];

  final List<Map<String, String>> topRatedCafes = [
    {'name': 'Annapoorna Gowrishankar', 'rating': '4.8'},
    {'name': 'The French Door', 'rating': '4.6'},
    {'name': 'Brew Haven', 'rating': '4.5'},
    {'name': 'Coffee Corner', 'rating': '4.4'},
  ];

  final List<Map<String, String>> mostVouchedShops = [
    {'name': 'Brookfields Mall', 'rating': '4.7'},
    {'name': 'Cross-Cut Road', 'rating': '4.5'},
    {'name': 'Phoenix Market', 'rating': '4.3'},
    {'name': 'Gandhipuram Plaza', 'rating': '4.2'},
  ];

  void _simulateVouch(BuildContext context, String placeName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppTheme.primary,
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Vouch collected at $placeName!',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showFilterPanel() {
    showModalBottomSheet(
      context: context,
      builder: (context) => FilterPanel(
        onApply: (category, sortBy) {
          setState(() {
            _selectedCategory = category;
            _selectedSort = sortBy;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Explore Coimbatore'),
        actions: [
          IconButton(
            icon: Icon(_isMapView ? Icons.list : Icons.map),
            onPressed: () => setState(() => _isMapView = !_isMapView),
          ),
          IconButton(
            icon: const Icon(Icons.tune),
            onPressed: _showFilterPanel,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        children: [
          FadeInDown(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search for places or rewards...',
                  prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
                  filled: true,
                  fillColor: AppTheme.surface,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Top10Carousel(
            title: 'Top Rated Cafes',
            items: topRatedCafes,
            onItemTap: () => _simulateVouch(context, 'Cafe'),
          ),
          const SizedBox(height: 24),
          Top10Carousel(
            title: 'Most Vouched Shops',
            items: mostVouchedShops,
            onItemTap: () => _simulateVouch(context, 'Shop'),
          ),
          const SizedBox(height: 24),
          const Text('Nearby Places', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: nearbyPlaces.length,
            itemBuilder: (context, index) {
              final place = nearbyPlaces[index];
              return FadeInUp(
                delay: Duration(milliseconds: 100 * index),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BusinessDetailPage(
                          businessId: place['id']!,
                          businessName: place['name']!,
                          category: place['category']!,
                          location: 'Coimbatore',
                        ),
                      ),
                    );
                  },
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(place['name']!, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(place['category']!, style: TextStyle(fontSize: 14, color: Colors.grey[400])),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              place['campaign']!,
                              style: const TextStyle(fontSize: 14, color: AppTheme.primary, fontWeight: FontWeight.w500),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: Text(place['distance']!, style: TextStyle(fontSize: 12, color: Colors.grey[400])),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}
