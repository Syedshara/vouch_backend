import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vouch_app/pages/dashboard_page.dart';
import 'package:vouch_app/pages/login_page.dart';
import 'package:vouch_app/services/auth_service.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();

    return authService.isAuthenticated
        ? const DashboardPage()
        : const LoginPage();
  }
}