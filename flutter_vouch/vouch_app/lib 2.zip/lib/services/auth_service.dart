import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:convert';

class AuthService with ChangeNotifier {
  final _storage = const FlutterSecureStorage();
  static const String _sessionKey = 'supabase_session';

  final GoTrueClient _auth = Supabase.instance.client.auth;

  bool _isAuthenticated = false;
  bool get isAuthenticated => _isAuthenticated;

  AuthService() {
    _loadSession();
  }

  Future<void> _loadSession() async {
    final sessionString = await _storage.read(key: _sessionKey);
    if (sessionString != null) {
      final session = Session.fromJson(jsonDecode(sessionString));

      // --- FIX: Use null-aware access '?._
      final expiresAt = session?.expiresAt;
      if (expiresAt != null && expiresAt > DateTime.now().millisecondsSinceEpoch) {
        // Session is valid, recover it
        final response = await _auth.recoverSession(sessionString);
        if (response.session != null) {
          _isAuthenticated = true;
        } else {
          // --- FIX: Removed extra comma ---
          _isAuthenticated = false;
        }
      } else {
        _isAuthenticated = false;
      }
    } else {
      _isAuthenticated = false;
    }
    notifyListeners();
  }

  Future<String?> signUp({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      await _auth.signUp(
        email: email,
        password: password,
        data: {'role': 'customer', 'name': name},
      );
      return null; // Success
    } on AuthException catch (e) {
      return e.message;
    }
  }

  Future<String?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (response.session != null) {
        await _storage.write(key: _sessionKey, value: jsonEncode(response.session!.toJson()));
        _isAuthenticated = true;
        notifyListeners();
        return null; // Success
      }
      return 'An unknown error occurred';
    } on AuthException catch (e) {
      return e.message;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    await _storage.delete(key: _sessionKey);
    _isAuthenticated = false;
    notifyListeners();
  }

  Future<String?> getAuthToken() async {
    final sessionString = await _storage.read(key: _sessionKey);
    if (sessionString == null) return null;

    final session = Session.fromJson(jsonDecode(sessionString));

    // --- FIX: Use null-aware access '?. ---
    final expiresAt = session?.expiresAt;
    if (expiresAt == null || expiresAt <= DateTime.now().millisecondsSinceEpoch) {
      final response = await _auth.refreshSession();
      if (response.session != null) {
        await _storage.write(key: _sessionKey, value: jsonEncode(response.session!.toJson()));
        return response.session!.accessToken;
      }
      return null; // Refresh failed
    }

    // --- FIX: Use null-aware access '?. ---
    return session?.accessToken;
  }
}