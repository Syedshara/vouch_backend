// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:vouch_app/app_theme.dart';
import 'package:vouch_app/auth_gate.dart';
import 'package:vouch_app/providers/reward_provider.dart';
import 'package:vouch_app/providers/visit_provider.dart';
import 'package:vouch_app/providers/review_provider.dart';
import 'package:vouch_app/providers/location_provider.dart';
import 'package:vouch_app/providers/business_provider.dart';
import 'package:vouch_app/providers/vouch_provider.dart';
import 'package:vouch_app/services/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://hviazayuwexvsmcemyzi.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2aWF6YXl1d2V4dnNtY2VteXppIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MTkxODM4MywiZXhwIjoyMDc3NDk0MzgzfQ.0qY71XQG-IwZrTWtIZgbC5i8CpI6WXAjN7GJ8Ux317g',
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthService()),
        ChangeNotifierProvider(create: (context) => LocationProvider()),
        ChangeNotifierProvider(create: (context) => RewardProvider()),
        ChangeNotifierProvider(create: (context) => VisitProvider()),
        ChangeNotifierProvider(create: (context) => ReviewProvider()),
        ChangeNotifierProvider(create: (context) => BusinessProvider()),

        // VouchProvider depends on LocationProvider AND AuthService
        ChangeNotifierProxyProvider2<LocationProvider, AuthService, VouchProvider>(
          create: (context) => VouchProvider(
            context.read<LocationProvider>(),
            context.read<AuthService>(),
          ),
          update: (context, locationProvider, authService, vouchProvider) =>
              VouchProvider(locationProvider, authService),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vouch',
      theme: AppTheme.theme,
      home: const AuthGate(),
    );
  }
}