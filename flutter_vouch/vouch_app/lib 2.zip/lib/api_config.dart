class ApiConfig {
  // --- IMPORTANT ---
  // If you are using an Android Emulator, 'localhost' is 10.0.2.2
  // If you are using an iOS Simulator, 'localhost' is 127.0.0.1
  static const String baseUrl = 'http://10.145.154.182:8080/api';

}