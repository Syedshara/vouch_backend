import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:math';
import 'dart:async';

class LocationData {
  final double latitude;
  final double longitude;
  final String? address;

  LocationData({
    required this.latitude,
    required this.longitude,
    this.address,
  });
}

class LocationProvider with ChangeNotifier {
  LocationData? _currentLocation;
  bool _isLoading = false;
  String? _error;
  bool _locationPermissionGranted = false;

  StreamSubscription<Position>? _positionStreamSubscription;

  LocationData? get currentLocation => _currentLocation;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // --- THIS WAS THE TYPO ---
  bool get locationPermissionGranted => _locationPermissionGranted;
  // --- END FIX ---

  Future<bool> requestLocationPermission() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        _error = 'Location permission denied';
        _locationPermissionGranted = false;
      } else if (permission == LocationPermission.deniedForever) {
        _error = 'Location permission permanently denied. Please enable it in settings.';
        _locationPermissionGranted = false;
      } else {
        _locationPermissionGranted = true;
        // Permission granted, start the live stream
        await _startLocationStream();
      }
    } catch (e) {
      _error = 'Error requesting location permission: $e';
      _locationPermissionGranted = false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return _locationPermissionGranted;
  }

  Future<void> getCurrentLocation() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        _error = 'Location permission not granted';
        _isLoading = false;
        notifyListeners();
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      _currentLocation = LocationData(
        latitude: position.latitude,
        longitude: position.longitude,
      );

      // Now that we have the first location, start the live stream
      await _startLocationStream();

    } catch (e) {
      _error = 'Error getting location: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _startLocationStream() async {
    if (_positionStreamSubscription != null) return; // Already streaming

    final permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      return; // Not allowed
    }

    const LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10, // Update every 10 meters
    );

    _positionStreamSubscription = Geolocator.getPositionStream(
        locationSettings: locationSettings
    ).listen((Position position) {
      // This block runs on EVERY new location update
      _currentLocation = LocationData(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      notifyListeners(); // This notifies VouchProvider
    }, onError: (e) {
      _error = 'Location stream error: $e';
      notifyListeners();
    });
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const p = 0.017453292519943295;
    final a = 0.5 - cos((lat2 - lat1) * p) / 2 + cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return (12742 * asin(sqrt(a))).toDouble();
  }

  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    super.dispose();
  }
}