import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:vouch_app/api_config.dart';
import 'package:vouch_app/models/business_model.dart';
import 'package:vouch_app/providers/location_provider.dart';
import 'package:vouch_app/services/geofence_service.dart';
import 'package:vouch_app/services/auth_service.dart'; // <-- IMPORT
import 'package:latlong2/latlong.dart';
import 'dart:convert';

enum VouchStatus {
  idle,       // Default state
  outside,    // User is confirmed outside
  inside,     // User is confirmed inside, timer not yet started
  counting,   // Server-side timer is running
  vouching,   // App is verifying the vouch
  success,    // Vouch completed
  error       // An error occurred
}

class VouchProvider with ChangeNotifier {
  final LocationProvider _locationProvider;
  final AuthService _authService; // <-- ADD
  final GeofenceService _geofenceService = GeofenceService();

  Business? _currentBusiness;
  VouchStatus _status = VouchStatus.idle;
  Timer? _pollTimer; // This timer just *checks* the status
  int _secondsRemaining = 0;
  int _totalDwellTime = 0;

  Business? get currentBusiness => _currentBusiness;
  VouchStatus get status => _status;
  int get secondsRemaining => _secondsRemaining;
  int get totalDwellTime => _totalDwellTime;

  VouchProvider(this._locationProvider, this._authService) {
    _locationProvider.addListener(_onLocationUpdate);
  }

  @override
  void dispose() {
    _locationProvider.removeListener(_onLocationUpdate);
    _pollTimer?.cancel();
    super.dispose();
  }

  void _onLocationUpdate() {
    if (_currentBusiness == null || _locationProvider.currentLocation == null) {
      _setStatus(VouchStatus.idle);
      return;
    }

    final geofenceJson = _currentBusiness!.geofenceGeoJson;
    if (geofenceJson == null) {
      _setStatus(VouchStatus.error);
      return;
    }

    final userPoint = LatLng(
      _locationProvider.currentLocation!.latitude,
      _locationProvider.currentLocation!.longitude,
    );

    final bool isInside = _geofenceService.isPointInGeofence(userPoint, geofenceJson);

    if (isInside) {
      if (_status == VouchStatus.idle || _status == VouchStatus.outside) {
        // User just entered! Tell the server to start the timer.
        _startServerTimer();
      }
      _setStatus(VouchStatus.inside); // Go to 'inside' first
    } else {
      if (_status == VouchStatus.counting || _status == VouchStatus.inside) {
        // User just left! Tell the server to check the timer.
        _stopServerTimer();
      }
      _setStatus(VouchStatus.outside);
    }
  }

  // Called when page opens
  Future<void> startVouchProcess(Business business) async {
    _currentBusiness = business;
    _totalDwellTime = (business.dwellTimeMinutes * 60);
    // _totalDwellTime = 5; // FOR TESTING
    _secondsRemaining = _totalDwellTime;

    // Check the status immediately
    await _checkServerStatus();

    // Start polling to get live timer updates
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _checkServerStatus();
    });

    // Trigger a location check
    _onLocationUpdate();
  }

  // Called when page closes
  void stopVouchProcess() {
    _currentBusiness = null;
    _pollTimer?.cancel();
    _pollTimer = null;
    _setStatus(VouchStatus.idle);
  }

  Future<void> _startServerTimer() async {
    final token = await _authService.getAuthToken();
    if (token == null) return; // Not logged in

    await http.post(
      Uri.parse('${ApiConfig.baseUrl}/vouch/start'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'location_id': _currentBusiness!.id}),
    );
    // After starting, immediately check the status
    await _checkServerStatus();
  }

  Future<void> _stopServerTimer() async {
    _pollTimer?.cancel(); // Stop polling
    final token = await _authService.getAuthToken();
    if (token == null) return;

    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/vouch/stop'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'location_id': _currentBusiness!.id}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'completed') {
        _setStatus(VouchStatus.success);
      } else {
        _setStatus(VouchStatus.outside); // Failed duration
      }
    }
  }

  Future<void> _checkServerStatus() async {
    if (_currentBusiness == null) return;

    final token = await _authService.getAuthToken();
    if (token == null) return;

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/vouch/status/${_currentBusiness!.id}'),
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        switch (data['status']) {
          case 'completed':
            _setStatus(VouchStatus.success);
            _pollTimer?.cancel();
            break;
          case 'counting':
            _setStatus(VouchStatus.counting);
            _secondsRemaining = (data['seconds_remaining'] as num).toInt();
            _totalDwellTime = (data['dwell_time_total'] as num).toInt();
            break;
          case 'idle':
            _setStatus(VouchStatus.idle);
            break;
        }
      }
    } catch (e) {
      print('Status check error: $e');
      _setStatus(VouchStatus.error);
    }
  }

  void _setStatus(VouchStatus newStatus) {
    if (_status != newStatus) {
      _status = newStatus;
      notifyListeners();
    }
  }
}