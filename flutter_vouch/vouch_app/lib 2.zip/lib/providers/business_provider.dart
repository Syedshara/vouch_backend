import 'package:flutter/material.dart';
import 'package:vouch_app/models/business_model.dart';
import 'package:vouch_app/api_config.dart'; // <-- IMPORT
import 'package:http/http.dart' as http; // <-- IMPORT
import 'dart:convert'; // <-- IMPORT

class BusinessProvider with ChangeNotifier {
  // --- MOCK DATA REMOVED ---
  List<Business> _nearbyBusinesses = [];
  List<Business> _topBusinesses = [];
  List<Business> _newBusinesses = [];

  bool _isLoading = false;
  String? _error;

  List<Business> get nearbyBusinesses => _nearbyBusinesses;
  List<Business> get topBusinesses => _topBusinesses;
  List<Business> get newBusinesses => _newBusinesses;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // --- NEW FETCHING METHODS ---

  Future<void> fetchAllBusinesses() async {
    // This will run all fetches in parallel for the home page
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Run all fetches at the same time
      await Future.wait([
        fetchNearbyBusinesses(),
        fetchTopBusinesses(),
        fetchNewBusinesses(),
      ]);
    } catch (e) {
      _error = e.toString();
      print("Error fetching all businesses: $_error");
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> fetchNearbyBusinesses() async {
    _nearbyBusinesses = await _fetchBusinessesFromServer(sortBy: 'distance');
    notifyListeners();
  }

  Future<void> fetchTopBusinesses() async {
    _topBusinesses = await _fetchBusinessesFromServer(sortBy: 'top');
    notifyListeners();
  }

  Future<void> fetchNewBusinesses() async {
    _newBusinesses = await _fetchBusinessesFromServer(sortBy: 'new');
    notifyListeners();
  }

  // --- PRIVATE HELPER ---
  Future<List<Business>> _fetchBusinessesFromServer(
      {String sortBy = 'new'}) async {
    try {
      final url = Uri.parse('${ApiConfig.baseUrl}/public/locations?sortBy=$sortBy');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = json.decode(response.body);
        final List<Business> businesses =
        jsonData.map((json) => Business.fromJson(json)).toList();
        return businesses;
      } else {

        throw Exception('Failed to load businesses: ${response.body}');
      }
    } catch (e) {
      _error = e.toString();
      return []; // Return empty list on error
    }
  }

  // We keep the search logic, but it now searches the *fetched* list
  String _searchQuery = '';
  List<Business> _filteredBusinesses = [];
  String get searchQuery => _searchQuery;
  List<Business> get filteredBusinesses => _filteredBusinesses;

  void searchBusinesses(String query) {
    _searchQuery = query;
    if (query.isEmpty) {
      _filteredBusinesses = []; // Clear filter
    } else {
      // Search from the nearby list
      _filteredBusinesses = _nearbyBusinesses
          .where((business) =>
      business.name.toLowerCase().contains(query.toLowerCase()) ||
          business.category.toLowerCase().contains(query.toLowerCase()) ||
          business.location.toLowerCase().contains(query.toLowerCase()))
          .toList();
    }
    notifyListeners();
  }

  List<String> getCategories() {
    final categories = _nearbyBusinesses.map((b) => b.category).toSet().toList();
    return ['All', ...categories];
  }
}