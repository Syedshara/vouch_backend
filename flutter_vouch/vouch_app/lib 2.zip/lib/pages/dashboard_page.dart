// lib/pages/dashboard_page.dart
import 'package:flutter/material.dart';
import 'package:vouch_app/pages/profile_page.dart';
import 'package:vouch_app/pages/rewards_page.dart';
import 'package:vouch_app/pages/notifications_page.dart';
import 'package:vouch_app/pages/home_page.dart';

// --- NEW IMPORTS ---
import 'package:geofence_service/geofence_service.dart';
import 'package:provider/provider.dart';
import 'package:vouch_app/providers/business_provider.dart';
import 'package:vouch_app/providers/location_provider.dart';
import 'package:vouch_app/services/auth_service.dart';
import 'package:vouch_app/api_config.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
// --------------------

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedIndex = 0;
  late final PageController _pageController;

  // --- GEOFENCE LOGIC ---
  final _geofenceService = GeofenceService.instance.setup(
    interval: 5000,
    accuracy: 100,
    loiteringDelayMs: 60000,
    statusChangeDelayMs: 10000,
    useActivityRecognition: false,
    allowMockLocations: false,
    geofenceRadiusSortType: GeofenceRadiusSortType.DESC,
  );
  // --------------------------

  @override
  void initState() {
    super.initState();
    _pageController = PageController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _registerGeofences();
    });
  }

  Future<void> _registerGeofences() async {
    // Ensure we have location permission first
    final locationProvider = context.read<LocationProvider>();
    bool permissionGranted = locationProvider.locationPermissionGranted;
    if (!permissionGranted) {
      permissionGranted = await locationProvider.requestLocationPermission();
    }
    if (!permissionGranted) return; // Can't proceed without permission

    // 1. Fetch all businesses from your backend
    final businessProvider = context.read<BusinessProvider>();
    await businessProvider.fetchAllBusinesses(); // This populates the lists

    // 2. Create a list of Geofence objects
    final geofenceList = <Geofence>[];
    for (final business in businessProvider.nearbyBusinesses) {
      if (business.geofenceGeoJson != null) {
        geofenceList.add(Geofence(
          id: business.id, // Use the business ID
          data: {'businessName': business.name}, // Optional metadata
          latitude: business.latitude,
          longitude: business.longitude,
          radius: [
            GeofenceRadius(id: 'radius_100', length: 100), // 100-meter radius
          ],
        ));
      }
    }

    // 3. Register the list with the OS
    await _geofenceService.start(geofenceList);

    // Add the listener with correct signature
    _geofenceService.addGeofenceStatusChangeListener(_onGeofenceEvent);
  }

  // --- Background-safe event handler ---
  // Updated signature to match the API: (Geofence, GeofenceRadius, GeofenceStatus, Location)
  Future<void> _onGeofenceEvent(
      Geofence geofence,
      GeofenceRadius geofenceRadius,
      GeofenceStatus geofenceStatus,
      location,
      ) async {
    String locationId = geofence.id;
    print('Geofence event: $locationId, $geofenceStatus');

    if (geofenceStatus == GeofenceStatus.ENTER) {
      // User entered the geofence
      await _callVouchApi('start', locationId);
    } else if (geofenceStatus == GeofenceStatus.EXIT) {
      // User exited the geofence
      await _callVouchApi('stop', locationId);
    }
  }

  // --- Function to make API calls from background events ---
  Future<void> _callVouchApi(String action, String locationId) async {
    try {
      final authService = context.read<AuthService>();
      final token = await authService.getAuthToken();
      if (token == null) return; // Not logged in

      final url = Uri.parse('${ApiConfig.baseUrl}/vouch/$action');
      await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'location_id': locationId}),
      );
      print('Called /vouch/$action for $locationId');
    } catch (e) {
      print('Failed to call /vouch/$action: $e');
    }
  }
  // ----------------------------------------------------

  @override
  void dispose() {
    _pageController.dispose();
    // Remember to remove the listener
    _geofenceService.removeGeofenceStatusChangeListener(_onGeofenceEvent);
    super.dispose();
  }

  void _onItemTapped(int index) {
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _onPageChanged(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: _onPageChanged,
        children: const <Widget>[
          HomePage(),
          NotificationsPage(),
          RewardsPage(),
          ProfilePage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), activeIcon: Icon(Icons.explore), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_outlined), activeIcon: Icon(Icons.notifications), label: 'Inbox'),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard_outlined), activeIcon: Icon(Icons.card_giftcard), label: 'Rewards'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), activeIcon: Icon(Icons.person), label: 'Profile'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}