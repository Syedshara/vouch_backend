import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vouch_app/app_theme.dart';
import 'package:vouch_app/components/top_10_carousel.dart';
import 'package:vouch_app/components/filter_panel.dart';
import 'package:vouch_app/components/map_view.dart';
import 'package:vouch_app/components/business_card.dart';
import 'package:vouch_app/pages/business_detail_page.dart';
import 'package:vouch_app/providers/location_provider.dart';
import 'package:vouch_app/providers/business_provider.dart';
import 'package:vouch_app/models/business_model.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with AutomaticKeepAliveClientMixin {
  // This keeps the page state (like scroll position) alive
  // when you switch tabs on the dashboard.
  @override
  bool get wantKeepAlive => true;

  bool _isMapView = false;
  String _selectedCategory = 'All';
  String _selectedSort = 'distance';
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Fetch data after the first frame is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchData();
    });
  }

  Future<void> _fetchData() async {
    // Get both providers
    final locationProvider = context.read<LocationProvider>();
    final businessProvider = context.read<BusinessProvider>();

    bool permissionGranted = locationProvider.locationPermissionGranted;

    // 1. Check/request location permission
    if (!permissionGranted) {
      permissionGranted = await locationProvider.requestLocationPermission();
    }

    // 2. If we have permission, get location
    if (permissionGranted) {
      if (locationProvider.currentLocation == null) {
        await locationProvider.getCurrentLocation();
      }
      // 3. Once we have location, fetch all businesses from the server
      if (mounted) {
        // Use await to make sure it completes
        await businessProvider.fetchAllBusinesses();
      }
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showFilterPanel() {
    showModalBottomSheet(
      context: context,
      builder: (context) => FilterPanel(
        onApply: (category, sortBy) {
          setState(() {
            _selectedCategory = category;
            _selectedSort = sortBy;
          });
        },
      ),
    );
  }

  // This is the function you asked for, to pass the full Business object
  void _onBusinessTap(Business business) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BusinessDetailPage(
          business: business, // Pass the full object
        ),
      ),
    );
  }

  // Helper for carousel taps
  void _onTopBusinessTap(int index) {
    // We use context.read here because we are in a callback, not build()
    final topBusinesses = context.read<BusinessProvider>().topBusinesses;
    if (topBusinesses.length > index) {
      _onBusinessTap(topBusinesses[index]);
    }
  }

  // Helper for carousel taps
  void _onNewBusinessTap(int index) {
    final newBusinesses = context.read<BusinessProvider>().newBusinesses;
    if (newBusinesses.length > index) {
      _onBusinessTap(newBusinesses[index]);
    }
  }


  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin

    return Scaffold(
      appBar: AppBar(
        title: const Text('Explore Nearby'),
        actions: [
          IconButton(
            icon: Icon(_isMapView ? Icons.list : Icons.map),
            onPressed: () => setState(() => _isMapView = !_isMapView),
          ),
          IconButton(
            icon: const Icon(Icons.tune),
            onPressed: _showFilterPanel,
          ),
        ],
      ),
      body: Consumer2<LocationProvider, BusinessProvider>(
        builder: (context, locationProvider, businessProvider, child) {

          // Show loading spinner if we're getting location OR businesses
          if (locationProvider.isLoading || (businessProvider.isLoading && businessProvider.nearbyBusinesses.isEmpty)) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          // Show permission request button
          if (!locationProvider.locationPermissionGranted) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.location_off, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  const Text('Location permission required'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _fetchData, // Use our new method
                    child: const Text('Enable Location'),
                  ),
                ],
              ),
            );
          }

          // Show error if location is null
          final userLocation = locationProvider.currentLocation;
          if (userLocation == null) {
            return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Could not get location. Please try again.'),
                    ElevatedButton(
                      onPressed: _fetchData,
                      child: const Text('Retry'),
                    ),
                  ],
                )
            );
          }

          // Get all our business lists from the provider
          final nearbyBusinesses = businessProvider.nearbyBusinesses;
          final topBusinesses = businessProvider.topBusinesses;
          final newBusinesses = businessProvider.newBusinesses;

          // Determine which list to show in the grid (search or nearby)
          final displayBusinesses = businessProvider.searchQuery.isEmpty
              ? nearbyBusinesses
              : businessProvider.filteredBusinesses;

          // Show Map View
          if (_isMapView) {
            return MapView(
              userLat: userLocation.latitude,
              userLon: userLocation.longitude,
              businesses: displayBusinesses,
              onBusinessTap: _onBusinessTap, // Use helper
            );
          }

          // Show List View
          return ListView(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    businessProvider.searchBusinesses(value);
                  },
                  decoration: InputDecoration(
                    hintText: 'Search shops, cafes, malls...',
                    prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        businessProvider.searchBusinesses('');
                      },
                    )
                        : null,
                    filled: true,
                    fillColor: AppTheme.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),

              // Only show carousels if not searching
              if (businessProvider.searchQuery.isEmpty) ...[
                Top10Carousel(
                  title: 'Top Rated Shops',
                  items: topBusinesses.map((b) => {
                    'name': b.name,
                    'rating': b.rating.toStringAsFixed(1),
                    'image': b.imageUrl ?? '',
                  }).toList(),
                  onItemTap: (index) { // Pass the index
                    if(topBusinesses.length > index) _onBusinessTap(topBusinesses[index]);
                  },
                ),
                const SizedBox(height: 32),
                Top10Carousel(
                  title: 'New & Noteworthy',
                  items: newBusinesses.map((b) => {
                    'name': b.name,
                    'rating': b.rating.toStringAsFixed(1),
                    'image': b.imageUrl ?? '',
                  }).toList(),
                  onItemTap: (index) { // Pass the index
                    if(newBusinesses.length > index) _onBusinessTap(newBusinesses[index]);
                  },
                ),
                const SizedBox(height: 32),
              ],

              // Show search "not found"
              if (displayBusinesses.isEmpty && businessProvider.searchQuery.isNotEmpty)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32.0),
                    child: Column(
                      children: [
                        const Icon(Icons.search_off, size: 64, color: Colors.grey),
                        const SizedBox(height: 16),
                        const Text('No shops found for your search'),
                        const SizedBox(height: 8),
                        Text(
                          'Try a different keyword',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ],
                    ),
                  ),
                )
              // Show "no shops nearby"
              else if (displayBusinesses.isEmpty && businessProvider.searchQuery.isEmpty)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32.0),
                    child: Column(
                      children: [
                        const Icon(Icons.store, size: 64, color: Colors.grey),
                        const SizedBox(height: 16),
                        const Text('No shops found nearby'),
                        const SizedBox(height: 8),
                        Text(
                          'We are expanding to your area soon!',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ],
                    ),
                  ),
                )
              // Show the grid of businesses
              else ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      businessProvider.searchQuery.isEmpty ? 'All Nearby Shops' : 'Search Results',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  GridView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75, // You may need to adjust this
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemCount: displayBusinesses.length,
                    itemBuilder: (context, index) {
                      final business = displayBusinesses[index];
                      final distance = business.getDistance(
                        userLocation.latitude,
                        userLocation.longitude,
                      );
                      return BusinessCard(
                        business: business,
                        distance: distance,
                        onTap: () => _onBusinessTap(business), // This is now correct
                      );
                    },
                  ),
                ],
              const SizedBox(height: 32), // Extra space at the bottom
            ],
          );
        },
      ),
    );
  }
}