import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:provider/provider.dart';
import 'package:vouch_app/models/business_model.dart';
import 'package:vouch_app/providers/location_provider.dart';
import 'package:vouch_app/providers/vouch_provider.dart';
import 'package:vouch_app/app_theme.dart';
import 'package:vouch_app/components/geofence_detail_map.dart';
import 'package:animate_do/animate_do.dart';

class BusinessDetailPage extends StatefulWidget {
  final Business business; // <-- We now receive the full Business object

  const BusinessDetailPage({
    super.key,
    required this.business,
  });

  @override
  State<BusinessDetailPage> createState() => _BusinessDetailPageState();
}

class _BusinessDetailPageState extends State<BusinessDetailPage> {
  final MapController _mapController = MapController();

  @override
  void initState() {
    super.initState();
    // Tell the VouchProvider to start tracking THIS business
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<VouchProvider>().startVouchProcess(widget.business);
    });
  }

  @override
  void dispose() {
    // Tell the VouchProvider to stop tracking when we leave
    // We use addPostFrameCallback to ensure the provider still exists
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<VouchProvider>().stopVouchProcess();
      }
    });
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Listen to both providers
    final locationProvider = context.watch<LocationProvider>();
    final vouchProvider = context.watch<VouchProvider>();

    final userLocation = locationProvider.currentLocation;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.business.name),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- THE NEW MAP COMPONENT ---
            if (userLocation != null &&
                widget.business.geofenceGeoJson != null)
              SizedBox(
                height: 300,
                child: GeofenceDetailMap(
                  business: widget.business,
                  userLocation: userLocation,
                  mapController: _mapController,
                ),
              )
            else
              Container(
                height: 300,
                color: AppTheme.surface,
                child: const Center(child: CircularProgressIndicator()),
              ),

            // --- THE NEW VOUCH TIMER UI ---
            FadeInUp(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _getBorderColor(vouchProvider.status),
                    width: 2,
                  ),
                ),
                child: _buildVouchStatusWidget(vouchProvider),
              ),
            ),

            // --- Business Header (Original content) ---
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.business.name,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.category, size: 16, color: Colors.grey[400]),
                      const SizedBox(width: 8),
                      Text(widget.business.category,
                          style: TextStyle(color: Colors.grey[400])),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 16, color: Colors.grey[400]),
                      const SizedBox(width: 8),
                      Expanded(
                          child: Text(widget.business.location,
                              style: TextStyle(color: Colors.grey[400]))),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 100), // Extra space
          ],
        ),
      ),
    );
  }

  Color _getBorderColor(VouchStatus status) {
    switch (status) {
      case VouchStatus.inside:
      case VouchStatus.counting:
        return Colors.green;
      case VouchStatus.outside:
        return Colors.redAccent;
      case VouchStatus.success:
        return AppTheme.primary;
      default:
        return Colors.grey[800]!;
    }
  }

  Widget _buildVouchStatusWidget(VouchProvider vouchProvider) {
    String title;
    String subtitle;
    Widget icon;

    switch (vouchProvider.status) {
      case VouchStatus.counting:
        title = 'You are inside!';
        subtitle =
        'Hold on... vouching in ${vouchProvider.secondsRemaining}s';
        icon = CircularProgressIndicator(
          value: vouchProvider.secondsRemaining /
              (widget.business.dwellTimeMinutes * 60),
          color: Colors.green,
          strokeWidth: 6,
        );
        break;
      case VouchStatus.outside:
        title = 'You are outside the area';
        subtitle = 'Move inside the geofence to start the timer';
        icon = const Icon(Icons.warning, color: Colors.redAccent, size: 40);
        break;
      case VouchStatus.vouching:
        title = 'Vouching...';
        subtitle = 'Sending your proof-of-presence...';
        icon = const CircularProgressIndicator(strokeWidth: 6);
        break;
      case VouchStatus.success:
        title = 'Vouch Collected!';
        subtitle = 'You successfully vouched at ${widget.business.name}';
        icon = const Icon(Icons.check_circle, color: AppTheme.primary, size: 40);
        break;
      case VouchStatus.error:
        title = 'Vouch Failed';
        subtitle = 'We couldn\'t verify your vouch. Please try again.';
        icon = const Icon(Icons.error, color: Colors.redAccent, size: 40);
        break;
      default:
        title = 'Finding your location...';
        subtitle = 'Please wait...';
        icon = const CircularProgressIndicator(strokeWidth: 6);
    }

    return Column(
      children: [
        SizedBox(
          width: 50,
          height: 50,
          child: Center(child: icon),
        ),
        const SizedBox(height: 16),
        Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, color: Colors.grey[400]),
        ),
      ],
    );
  }
}